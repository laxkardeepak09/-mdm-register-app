MDM REGISTER — ANDROID APP PROJECT
==================================

This project wraps the existing MDM All-In-One Register in an Android app.
Installing the generated APK creates the MDM Register icon in the Android app drawer/home screen.

APP FEATURES
- Existing seven-register MDM web interface and local data storage
- App icon and standalone Android app window
- JSON backup and CSV export through Android's Save dialog
- JSON restore through Android's file picker
- Print action through Android print service

IMPORTANT
- The app needs an internet connection for the existing Tailwind CSS and Google Fonts CDN resources used by the original HTML.
- Register data is stored locally on this phone/browser app installation. It does not automatically sync to another phone.
- This is a debug APK build configuration. For public Play Store distribution, create a signed release build and review privacy/data policies.

BUILD THE APK WITHOUT ANDROID STUDIO (GitHub Actions)
1. Extract this ZIP on a computer.
2. Create a new GitHub repository.
3. Upload all files and folders from this project to the repository (the .github folder must also be uploaded).
4. Open the repository's Actions tab.
5. Select "Build MDM Register APK" and click "Run workflow".
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, find Artifacts, and download "MDM-Register-APK".
8. Extract the artifact ZIP to get app-debug.apk.
9. Send app-debug.apk to the Android phone. Open it and follow Android's install prompts. If asked, allow "Install unknown apps" for the app used to open the APK.

BUILD LOCALLY
Open this folder in Android Studio (recent version), allow Gradle sync, then run Build > Build Bundle(s) / APK(s) > Build APK(s).

PACKAGE
Application ID: com.mggsaarni.mdmregister
Version: 1.0
Minimum Android: 6.0 (API 23)
